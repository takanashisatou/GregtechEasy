package org.satou.gtecore.common.data;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.GTCEuAPI;
import com.gregtechceu.gtceu.api.block.ActiveBlock;
import com.gregtechceu.gtceu.api.block.ICoilType;
import com.gregtechceu.gtceu.api.block.property.GTBlockStateProperties;
import com.gregtechceu.gtceu.common.block.CoilBlock;
import com.gregtechceu.gtceu.common.data.models.GTModels;
import com.gregtechceu.gtceu.data.recipe.CustomTags;
import com.lowdragmc.lowdraglib.test.TestJava;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import com.tterrag.registrate.util.entry.BlockEntry;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import com.tterrag.registrate.util.nullness.NonNullSupplier;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.GlassBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.client.model.generators.ModelFile;
import org.satou.gtecore.GTECore;
import org.satou.gtecore.api.registry.GTECoreRegistration;
import org.satou.gtecore.common.ActiveGlassBlock;
import org.satou.gtecore.common.GTECoilBlock;

import java.util.function.Supplier;

import static com.gregtechceu.gtceu.common.registry.GTRegistration.REGISTRATE;
import static org.satou.gtecore.api.registry.GTECoreRegistration.GTECore_REGISTRATE;
import static org.satou.gtecore.common.data.GTECreativeModeTabs.MORE_MACHINES;

public class GTEBlocks {
    static {
        GTECore_REGISTRATE.creativeModeTab(()->MORE_MACHINES);
    }
    public static BlockEntry<Block> SUPER_STRING_CASING = createCasingBlock("super_string_casing",GTECore.id("block/casings/super_string_casing/super_string_casing"));
    public static BlockEntry<ActiveBlock> IMAGINARY_CASING = createActiveLightCasingBlock("imaginary_casing", GTECore.id("block/casings/imaginary/imaginary_casing"), 8, 15);
    public static BlockEntry<ActiveBlock> IMAGINARY_CORE_CASING = createActiveLightCasingBlock("imaginary_core_casing", GTECore.id("block/casings/imaginary/imaginary_core_casing"), 12, 15);
    public static BlockEntry<ActiveBlock> IMAGINARY_BRANCH_CASING = createActiveLightCasingBlock("imaginary_branch_casing", GTECore.id("block/casings/imaginary/imaginary_branch_casing"), 10, 15);
    public static BlockEntry<ActiveBlock> IMAGINARY_CONTAINMENT_CASING = createActiveLightCasingBlock("imaginary_containment_casing", GTECore.id("block/casings/imaginary/imaginary_containment_casing"), 7, 15);
    public static BlockEntry<GTECoilBlock> IMAGINARY_COIL = createCoilBlock(GTECoilBlock.GTECoilType.IMAGINARY_COIL);
    public static BlockEntry<ActiveBlock> IMAGINARY_ENERGY_CONDUIT = createActiveLightCasingBlock("imaginary_energy_conduit", GTECore.id("block/casings/imaginary/imaginary_energy_conduit"), 12, 15);
    public static BlockEntry<ActiveGlassBlock> IMAGINARY_GLASS = GTECore_REGISTRATE.block("imaginary_glass", ActiveGlassBlock::new)
            .initialProperties(() -> Blocks.GLASS)
            .properties(p -> p.isValidSpawn((state, level, pos, ent) -> false)
                    .lightLevel(state -> state.getValue(GTBlockStateProperties.ACTIVE) ? 15 : 10))
            .addLayer(() -> RenderType::translucent)
            .blockstate(createActiveBloomModel(GTECore.id("block/casings/imaginary/imaginary_glass")))
            .tag(CustomTags.MINEABLE_WITH_CONFIG_VALID_PICKAXE_WRENCH)
            .item(BlockItem::new)
            .build()
            .register();
    public static BlockEntry<ActiveBlock> IMAGINARY_LEAF_MATRIX = GTECore_REGISTRATE.block("imaginary_leaf_matrix", ActiveBlock::new)
            .initialProperties(() -> Blocks.OAK_LEAVES)
            .properties(p -> p.isValidSpawn((state, level, pos, ent) -> false)
                    .noOcclusion()
                    .isSuffocating((state, level, pos) -> false)
                    .isViewBlocking((state, level, pos) -> false)
                    .lightLevel(state -> state.getValue(GTBlockStateProperties.ACTIVE) ? 15 : 8))
            .addLayer(() -> RenderType::cutoutMipped)
            .blockstate(createActiveBloomModel(GTECore.id("block/casings/imaginary/imaginary_leaf_matrix")))
            .tag(CustomTags.MINEABLE_WITH_CONFIG_VALID_PICKAXE_WRENCH)
            .item(BlockItem::new)
            .build()
            .register();

    public static BlockEntry<Block> EIGHT_TRIGMAS_CASING = createCasingBlock("eight_trigmas_casing",GTECore.id("block/casings/eight_trigmas/eight_trigmas_casing"));
    public static BlockEntry<GTECoilBlock> YIN_YANG_COIL = createCoilBlock(GTECoilBlock.GTECoilType.YIN_YANG_COIL);
    public static BlockEntry<Block> KAN_SHUI_CASING = createCasingBlock("kan_shui_casing",GTECore.id("block/casings/uhv/kan_shui_casing"));
    public static BlockEntry<Block> KUN_GEN_CASING = createCasingBlock("kun_gen_casing",GTECore.id("block/casings/uhv/kun_gen_casing"));
    public static BlockEntry<Block> LI_HUO_CASING = createCasingBlock("li_huo_casing",GTECore.id("block/casings/uhv/li_huo_casing"));

    public static BlockEntry<Block> BASE_DARK_CONCRETE = createCasingBlock("base_dark_concrete",GTECore.id("block/casings/concrete/base_dark_concrete"));
    public static BlockEntry<Block> BASE_LIGHT_CONCRETE = createCasingBlock("base_light_concrete",GTECore.id("block/casings/concrete/base_light_concrete"));
    public static BlockEntry<Block> BASE_MID_CONCRETE = createCasingBlock("base_mid_concrete",GTECore.id("block/casings/concrete/base_mid_concrete"));
    public static BlockEntry<Block> YIN_YANG_FIELD_RESTRICTION = createCasingBlock("yin_yang_field_restriction",GTECore.id("block/casings/yin_yang_field_restriction/yin_yang_field_restriction"));

    public static BlockEntry<Block> BAIHU_MODULE = createCasingBlock("baihu_module",GTECore.id("block/casings/uhv/baihu_module"));
    public static BlockEntry<Block> QINLONG_MODULE = createCasingBlock("qinglong_module",GTECore.id("block/casings/uhv/qinglong_module"));
    public static BlockEntry<Block> XUANWU_MODULE = createCasingBlock("xuanwu_module",GTECore.id("block/casings/uhv/xuanwu_module"));
    public static BlockEntry<Block> ZHUQUE_MODULE = createCasingBlock("zhuque_module",GTECore.id("block/casings/uhv/zhuque_module"));

    public static BlockEntry<Block> createLightCasingBlock(String name, ResourceLocation texture, int lightLevel) {
        return GTECore_REGISTRATE.block(name, Block::new)
                .initialProperties(() -> Blocks.IRON_BLOCK)
                .properties(p -> p.isValidSpawn((state, level, pos, ent) -> false).lightLevel(state -> lightLevel))
                .addLayer(() -> RenderType::solid)
                .exBlockstate(GTModels.cubeAllModel(texture))
                .tag(CustomTags.MINEABLE_WITH_CONFIG_VALID_PICKAXE_WRENCH)
                .item(BlockItem::new)
                .build()
                .register();
    }

    public static BlockEntry<Block> createCasingBlock(String name, ResourceLocation texture) {
        return createCasingBlock(name, Block::new, texture, () -> Blocks.IRON_BLOCK,
                () -> RenderType::solid);
    }

    public static BlockEntry<Block> createCasingBlock(String name, ResourceLocation texture,
                                                      Supplier<Supplier<RenderType>> type) {
        return createCasingBlock(name, Block::new, texture, () -> Blocks.IRON_BLOCK, type);
    }

    public static BlockEntry<GlassBlock> createGlassCasingBlock(String name, ResourceLocation texture,
                                                                 Supplier<Supplier<RenderType>> type) {
        return GTECore_REGISTRATE.block(name, GlassBlock::new)
                .initialProperties(() -> Blocks.GLASS)
                .properties(p -> p.isValidSpawn((state, level, pos, ent) -> false).lightLevel(state -> 10))
                .addLayer(type)
                .exBlockstate(GTModels.cubeAllModel(texture))
                .tag(CustomTags.MINEABLE_WITH_CONFIG_VALID_PICKAXE_WRENCH)
                .item(BlockItem::new)
                .build()
                .register();
    }
    private static BlockEntry<GTECoilBlock> createCoilBlock(ICoilType coilType) {
        //GTCEuAPI.HEATING_COILS.put(coilType, coilBlock);
        return GTECore_REGISTRATE
                .block("%s_coil_block".formatted(coilType.getName()), p -> new GTECoilBlock(p, coilType))
                .initialProperties(() -> Blocks.IRON_BLOCK)
                .properties(p -> p.isValidSpawn((state, level, pos, ent) -> false)
                        .lightLevel(state -> state.getValue(GTBlockStateProperties.ACTIVE) ? 15 : 0))
                .addLayer(() -> RenderType::cutoutMipped)
                .blockstate(GTEBlocks.createCoilModel(coilType))
                .tag(CustomTags.MINEABLE_WITH_CONFIG_VALID_PICKAXE_WRENCH)
                .item(BlockItem::new)
                .build()
                .register();
    }

    public static BlockEntry<ActiveBlock> createActiveLightCasingBlock(String name, ResourceLocation texture, int idleLight, int activeLight) {
        return GTECore_REGISTRATE.block(name, ActiveBlock::new)
                .initialProperties(() -> Blocks.IRON_BLOCK)
                .properties(p -> p.isValidSpawn((state, level, pos, ent) -> false)
                        .lightLevel(state -> state.getValue(GTBlockStateProperties.ACTIVE) ? activeLight : idleLight))
                .addLayer(() -> RenderType::cutoutMipped)
                .blockstate(createActiveBloomModel(texture))
                .tag(CustomTags.MINEABLE_WITH_CONFIG_VALID_PICKAXE_WRENCH)
                .item(BlockItem::new)
                .build()
                .register();
    }

    public static <T extends ActiveBlock> NonNullBiConsumer<DataGenContext<Block, T>, RegistrateBlockstateProvider> createActiveBloomModel(ResourceLocation texture) {
        return (ctx, prov) -> {
            String name = ctx.getName();
            ActiveBlock block = ctx.getEntry();
            ModelFile inactive = prov.models().cubeAll(name, texture);
            ModelFile active = prov.models().withExistingParent(name + "_active", GTECore.id("block/cube_2_layer/all"))
                    .texture("bot_all", texture)
                    .texture("top_all", texture.withSuffix("_bloom"));
            prov.getVariantBuilder(block)
                    .partialState().with(GTBlockStateProperties.ACTIVE, false).modelForState().modelFile(inactive)
                    .addModel()
                    .partialState().with(GTBlockStateProperties.ACTIVE, true).modelForState().modelFile(active)
                    .addModel();
        };
    }

    public static NonNullBiConsumer<DataGenContext<Block, GTECoilBlock>, RegistrateBlockstateProvider> createCoilModel(ICoilType coilType) {
        return (ctx, prov) -> {
            String name = ctx.getName();
            ActiveBlock block = ctx.getEntry();
            ModelFile inactive = prov.models().cubeAll(name, coilType.getTexture());
            ModelFile active = prov.models().withExistingParent(name + "_active", GTECore.id("block/cube_2_layer/all"))
                    .texture("bot_all", coilType.getTexture())
                    .texture("top_all", coilType.getTexture().withSuffix("_bloom"));
            prov.getVariantBuilder(block)
                    .partialState().with(GTBlockStateProperties.ACTIVE, false).modelForState().modelFile(inactive)
                    .addModel()
                    .partialState().with(GTBlockStateProperties.ACTIVE, true).modelForState().modelFile(active)
                    .addModel();
        };
    }
    public static BlockEntry<Block> createCasingBlock(String name,
                                                      NonNullFunction<BlockBehaviour.Properties, Block> blockSupplier,
                                                      ResourceLocation texture,
                                                      NonNullSupplier<? extends Block> properties,
                                                      Supplier<Supplier<RenderType>> type) {
        return GTECore_REGISTRATE.block(name, blockSupplier)
                .initialProperties(properties)
                .properties(p -> p.isValidSpawn((state, level, pos, ent) -> false))
                .addLayer(type)
                .exBlockstate(GTModels.cubeAllModel(texture))
                .tag(CustomTags.MINEABLE_WITH_CONFIG_VALID_PICKAXE_WRENCH)
                .item(BlockItem::new)
                .build()
                .register();
    }
    public static void init() {}
}

