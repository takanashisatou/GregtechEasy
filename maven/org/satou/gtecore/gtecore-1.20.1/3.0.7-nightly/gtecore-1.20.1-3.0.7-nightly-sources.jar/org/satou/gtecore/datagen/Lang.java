package org.satou.gtecore.datagen;

public class Lang {

        public static void init(CommonLanguageProvider provider) {
                provider.add("config.jade.plugin_pipez.pipe", "Pipes", "管道");
                provider.add("config.gtecore.option.superPeace", "Super Peace Mode", "超级和平模式");
                provider.add("config.gtecore.option.durationMultiplier", "recipe time multiplier", "配方时间倍率");
                provider.add("block.gtecore.steam_op", "Steam Ore Processing Factory", "蒸汽矿物处理厂");
                provider.add("config.screen.gtecore", "gtecore configure menu", "gtecore配置菜单");
                provider.add("gtecore.steam_op_recipe", "Steam Ore Processing Factory", "蒸汽矿物处理厂");
                provider.add("itemGroup.gtecore.gtecore_machines", "GregTech Easy Machines", "格雷科技Easy机器");
                provider.add("itemGroup.gtecore.gtecore_items", "Gregtech Easy Items", "格雷科技Easy物品");
                provider.add("com.gtecore.tooltips.addbygtecore", "Added by GTECore ", "由GTECore添加");
                provider.add("com.gtecore.tooltips.steam_op",
                                "1B parallels and all recipe will finish in 1tick，support all input and output machine parts",
                                "10亿并行，并且所有配方1tick执行完毕，支持所有类型的输入输出仓室");
                provider.add("com.gtecore.tooltips.chemistry_terminator",
                                "The magical machine has overturned the existence of chemistry and physics, and its emergence undoubtedly marks the end of chemistry",
                                "神奇的机器，颠覆了化学与物理的存在，它的出现无疑代表着化学的终结");
                provider.add("block.gtecore.chemistry_terminator", "Chemistry Terminator", "化学终结者");
                provider.add("gtecore.chemistry_terminator_recipe", "Chemistry Terminator", "化学终结者");
                provider.add("block.gtecore.ten_in_one", "Ten in One General Processing Factory", "十合一通用处理工厂");
                provider.add("item.gtecore.super_string_processor", "Super String Processor", "超弦处理器");
                provider.add("item.gtecore.super_string_processor_assembly", "Super String Processor Assembly",
                                "超弦处理器集群");
                provider.add("item.gtecore.super_string_processor_computer", "Super String Processor Computer",
                                "超弦处理器超级计算机");
                provider.add("item.gtecore.super_string_processor_mainframe", "Super String Processor Mainframe",
                                "超弦处理器主机");
                provider.add("item.gtecore.super_string_processor.tooltip.0",
                                "§7 Circuits from the Superstring Dimension", "§7来自超弦维度的电路");
                provider.add("item.gtecore.super_string_processor.tooltip.1", "§dZPM-level circuits", "§dZPM级电路");
                provider.add("item.gtecore.super_string_processor_assembly.tooltip.0",
                                "§7 Circuits from the Superstring Dimension", "§7来自超弦维度的电路");
                provider.add("item.gtecore.super_string_processor_assembly.tooltip.1", "§dUV-level circuits",
                                "§dUV级电路");
                provider.add("item.gtecore.super_string_processor_computer.tooltip.0",
                                "§7 Circuits from the Superstring Dimension", "§7来自超弦维度的电路");
                provider.add("item.gtecore.super_string_processor_computer.tooltip.1", "§dUHV-level circuits",
                                "§dUHV级电路");
                provider.add("item.gtecore.super_string_processor_mainframe.tooltip.0",
                                "§7 Circuits from the Superstring Dimension", "§7来自超弦维度的电路");
                provider.add("item.gtecore.super_string_processor_mainframe.tooltip.1", "§dUEV-level circuits",
                                "§dUEV级电路");
                provider.add("com.gtecore.tooltips.super_fusion_reactor", "Support 1T OC, Very Fast!",
                                "支持1TOC,再也不用慢慢等聚变了!");
                provider.add("block.gtecore.super_fusion_reactor", "Super Fusion Reactor", "超级聚变反应堆");
                provider.add("gtecore.super_fusion_reactor_recipe", "Super Fusion Reactor", "超级聚变反应堆");
                provider.add("block.gtecore.distillation_tower_easy", "Distillation Tower Easy", "蒸馏塔简单版");
                provider.add("block.gtecore.super_string_casing", "§d Super String Casing", "§d超弦外壳");
                provider.add("block.gtecore.super_string_mixer", "§d Super String Mixer", "§d超弦搅拌机");
                provider.add("gtecore.super_string_mixing", "§d Super String Mixing", "§d超弦搅拌");
                provider.add("block.gtecore.string_of_creation", "§d String Of Creation", "§d创世之弦");
                provider.add("gtecore.string_of_creation", "§d String Of Creation", "§d创世之弦");
                provider.add("block.gtecore.super_string_oscillator_array", "§d Super String Oscillator Array",
                                "§d超弦震荡阵列");
                provider.add("gtecore.super_string_oscillator_array", "§d Super String Oscillator Array", "§d超弦震荡阵列");
                provider.add("block.gtecore.chord_of_all_things", "§d Chord Of All Things", "§d 万物之弦");
                provider.add("gtecore.chord_of_all_things", "§d Chord Of All Things", "§d 万物之弦");
                provider.add("item.gtecore.super_string_circuit_board", "§d Super String Circuit Board", "§d 超弦电路基板");
                provider.add("item.gtecore.super_string_printed_circuit_board", "§d Super String Printed Circuit Board",
                                "§d 超弦电路印刷基板");
                provider.add("item.gtecore.original_string", "§d Original String", "§d起源之弦");
                provider.add("item.gtecore.alpha_string", "§d α String", "§d α弦");
                provider.add("item.gtecore.beta_string", "§d β String", "§d β弦");
                provider.add("item.gtecore.gamma_string", "§d γ String", "§d γ弦");
                provider.add("block.gtecore.easy_fluid_drilling_rig", "Easy Fluid Drilling", "简单流体钻机");
                provider.add("gtecore.easy_fluid", "Easy Fluid", "简单流体");
                provider.add("block.gtecore.not_hard_fluid_drilling_rig", "Not Hard Fluid Drilling Rig", "不难流体钻机");
                provider.add("block.gtecore.molecular_separators", "§3Molecular Separators", "§3分子离析者");
                provider.add("gtecore.molecular_separators", "§3Molecular Separators", "§3分子离析者");
                provider.add("block.gtecore.easy_box", "§6Easy §3B§2o§1x ", "§6简§3单§2之§1盒");
                provider.add("gtecore.easy_box", "§6Easy §3B§2o§1x ", "§6简§3单§2之§1盒");
                provider.add("block.gtecore.integrated_petrochemical_plant", "Integrated Petrochemical Plant",
                                "综合石化工厂");
                provider.add("gtecore.integrated_petrochemical_plant", "Integrated Petrochemical Plant", "综合石化工厂");
                provider.add("gtecore.ore_process_center", "§6Ore Processing", "§6矿石处理");
                provider.add("block.gtecore.ore_process_center", "§6Ore Processing Center", "§6矿石处理中心");
                provider.add("com.gtecore.ore_process_center.tooltips.0",
                                "§The §6Ore Processing Center§r has seven different types of recipes",
                                "§6矿石处理中心§r拥有七种不同类型的配方");
                provider.add("com.gtecore.ore_process_center.tooltips.1", "Circuit 1: Crushing-Crushing-Washing",
                                "电路1: 粉碎-粉碎-洗矿");
                provider.add("com.gtecore.ore_process_center.tooltips.2", "Circuit 2: Crushing-Crushing-Centrifugation",
                                "电路2: 粉碎-粉碎-离心");
                provider.add("com.gtecore.ore_process_center.tooltips.3",
                                "Circuit 3: Crushing-Washing-Thermal Separation-Crushing", "电路3: 粉碎-洗矿-热离-粉碎");
                provider.add("com.gtecore.ore_process_center.tooltips.4",
                                "Circuit 4: Crushing-Thermal Separation-Crushing", "电路4: 粉碎-热离-粉碎");
                provider.add("com.gtecore.ore_process_center.tooltips.5",
                                "Circuit 5: Crushing-Washing-Crushing-Washing", "电路5: 粉碎-洗矿-粉碎-洗矿");
                provider.add("com.gtecore.ore_process_center.tooltips.6",
                                "Circuit 6: Crushing-Washing-Crushing-Centrifugation", "电路6: 粉碎-洗矿-粉碎-离心");
                provider.add("com.gtecore.ore_process_center.tooltips.7",
                                "Circuit 8: Crushing-Washing-Crushing-Electromagnetic Separation",
                                "电路8: 粉碎-洗矿-粉碎-电磁选矿");
                provider.add("com.gtecore.ore_process_center.tooltips.8", "Support subtick overclock", "支持1T OC");
                provider.add("block.gtecore.star_core_cooling_matrix", "§3 Star Core Cooling Matrix", "§3 星核冷却矩阵");
                provider.add("block.gtecore.max_super_battery_buffer_1x", "§c§lMaximum Voltage§r Super Battery Buffer",
                                "§c上限压§r超级电池箱（§c§lMAX§r）");
                provider.add("block.gtecore.me_steam_hatch", "ME Steam Hatch", "ME蒸汽仓");
                provider.add("block.gtecore.not_hard_box", "Not §6Hard §3B§2o§1x", "§6不§3难§2之§1盒");
                provider.add("com.gtecore.not_hard_box.tooltips.0", "Electricity version of the §6Easy §3B§2o§1x",
                                "§6简§3单§2之§1盒§r的电力版本");
                provider.add("com.gtecore.tooltips.10", "Can Use MultiParallel Hatch", "可使用跨配方并行仓");
                provider.add("block.gtecore.large_general_generator", "Large General Generator", "大型通用发电机");
                provider.add("block.gtecore.wiremill_factory", "§6 Wiremill Factory", "§6 导线工厂");
                provider.add("gtecore.wiremill_factory", "§6 Wiremill Factory", "§6 导线工厂");
                provider.add("com.gtecore.wiremill_factory.tooltips.0",
                                "§6Wiremill Factory§r can make all types of wiremills", "§6导线工厂§r可以制造各种种类的导线");
                provider.add("gtecore.crystal_center", "§6 Crystal Center", "§6 晶核中枢");
                provider.add("block.gtecore.crystal_center", "§6 Crystal Center", "§6 晶核中枢");
                provider.add("gtecore.quantum_cable_assembler", "§6 Quantum Cable Assembler", "§6 量子线擎");
                provider.add("block.gtecore.quantum_cable_assembler", "§6 Quantum Cable Assembler", "§6 量子线擎");
                provider.add("gtecore.starblade_etching", "§3 Starblade Etching", "§3星刃蚀刻");
                provider.add("block.gtecore.starblade_etching_machine", "§3 Starblade Etching", "§3星刃蚀刻仪");
                provider.add("item.gtecore.yin_yang_processor.tooltip.0",
                                "§7Yin gives rise to Yang, and Yang gives rise to Yin", "§7阴生阳，阳生阴");
                provider.add("item.gtecore.yin_yang_processor.tooltip.1", "§8UV-Level Circuits", "§8UV级电路");
                provider.add("item.gtecore.yin_yang_processor", "Ying Yang Processor", "阴阳处理器");
                provider.add("item.gtecore.yin_yang_processor_assembly.tooltip.0",
                                "§7Yin gives rise to Yang, and Yang gives rise to Yin", "§7阴生阳，阳生阴");
                provider.add("item.gtecore.yin_yang_processor_assembly.tooltip.1", "§8UHV-Level Circuits", "§8UHV级电路");
                provider.add("item.gtecore.yin_yang_processor_assembly", "Ying Yang Processor Assembly", "阴阳处理器集群");
                provider.add("item.gtecore.yin_yang_processor_computer.tooltip.0",
                                "§7Yin gives rise to Yang, and Yang gives rise to Yin", "§7阴生阳，阳生阴");
                provider.add("item.gtecore.yin_yang_processor_computer.tooltip.1", "§8UEV-Level Circuits", "§8UEV级电路");
                provider.add("item.gtecore.yin_yang_processor_computer", "Ying Yang Processor Computer", "阴阳处理器超级计算机");
                provider.add("item.gtecore.yin_yang_processor_mainframe.tooltip.0",
                                "§7Yin gives rise to Yang, and Yang gives rise to Yin", "§7阴生阳，阳生阴");
                provider.add("item.gtecore.yin_yang_processor_mainframe.tooltip.1", "§8UIV-Level Circuits", "§8UIV级电路");
                provider.add("item.gtecore.yin_yang_processor_mainframe", "Ying Yang Processor Mainframe", "阴阳处理器主机");
                provider.add("block.gtecore.antimatter_ball", "§5 Antimatter Ball", "§5暗能脉冲反物质核心");
                provider.add("gtecore.antimatter_transformation", "§5 Antimatter Transformation", "§5反物质变换");
                provider.add("block.gtecore.eight_trigmas_casing", "§8Eight Trigmas Casing", "§8八卦机械方块");
                provider.add("block.gtecore.yin_yang_coil_block", "§8Yin Yang Coil Block", "§8阴阳线圈方块");
                provider.add("material.gtecore.huo", "§4Fire Element", "§4火元素");
                provider.add("material.gtecore.shuiyuansu", "§3Water Element", "§3水元素");
                provider.add("material.gtecore.jinyuansu", "§eGold Element", "§e金元素");
                provider.add("material.gtecore.muyuansu", "§2Wood Element", "§2木元素");
                provider.add("material.gtecore.tuyuansu", "§8Earth Element", "§8土元素");
                provider.add("item.gtecore.rune_dui", "Rune Dui", "兑象");
                provider.add("item.gtecore.rune_gen", "Rune Gen", "艮象");
                provider.add("item.gtecore.rune_kan", "Rune Kan", "坎象");
                provider.add("item.gtecore.rune_kun", "Rune Kun", "坤象");
                provider.add("item.gtecore.rune_li", "Rune Li", "离象");
                provider.add("item.gtecore.rune_qian", "Rune Qian", "乾象");
                provider.add("item.gtecore.rune_xun", "Rune Xun", "巽象");
                provider.add("item.gtecore.rune_zhen", "Rune Zhen", "震象");
                provider.add("item.gtecore.symbol_paper_earth", "§8Paper of Earth", "§8土之符篆");
                provider.add("item.gtecore.symbol_paper_fire", "§4Symbol Paper of Fire", "§4火之符篆");
                provider.add("item.gtecore.symbol_paper_water", "§3Symbol Paper of Water", "§3水之符篆");
                provider.add("item.gtecore.symbol_paper_wood", "§2Symbol Paper of Wood", "§2木之符篆");
                provider.add("item.gtecore.symbol_paper_gold", "§2Symbol Paper of Gold", "§e金之符篆");
                provider.add("item.gtecore.yin", "§8Yin", "§8阴");
                provider.add("item.gtecore.yang", "Yang", "阳");
                provider.add("item.gtecore.dui_chip", "Dui Chip", "兑芯");
                provider.add("item.gtecore.gen_chip", "Gen Chip", "艮芯");
                provider.add("item.gtecore.god_nugget", "God Nugget", "三清之粒");
                provider.add("item.gtecore.yin_yang_wafer", "§8Yin§rYang Wafer", "§8阴§r阳晶圆");
                provider.add("block.gtecore.kan_shui_casing", "§3Kan Shui Casing", "§3坎水机械方块");
                provider.add("block.gtecore.kun_gen_casing", "§8Kun Gen Casing", "§8坤艮机械方块");
                provider.add("block.gtecore.li_huo_casing", "§4Li Huo Casing", "§4离火机械方块");
                provider.add("item.gtecore.yinyang_glass_lens", "§8Yin §rYang Glass Lens", "§8阴§r阳透镜");
                provider.add("block.gtecore.base_dark_concrete", "Base Dark Concrete", "§8阴极§r混凝土");
                provider.add("block.gtecore.base_light_concrete", "Base Light Concrete", "阳盛混凝土");
                provider.add("block.gtecore.base_mid_concrete", "Base Medium Concrete", "中庸混凝土");
                provider.add("block.gtecore.yin_yang_field_restriction", "§8Yin §rYang Field Restriction",
                                "§8阴§r阳立场约束方块");
                provider.add("block.gtecore.baihu_module", "§fWhite Tiger Module", "§f白虎阵法方块");
                provider.add("block.gtecore.qinglong_module", "§3Azure Dragon Module", "§3青龙阵法方块");
                provider.add("block.gtecore.xuanwu_module", "§8Black Tortoise Module", "§8玄武阵法方块");
                provider.add("block.gtecore.zhuque_module", "§cVermilion Bird Module", "§c朱雀阵法方块");

                provider.add("block.gtecore.yin_yang_eight_trigmas_blast_furnace",
                                "§8Yin §rYang Eight Trigmas Blast Furnace", "§5紫薇§8八卦§6炼仙炉");
                provider.add("gtecore.yin_yang_eight_trigmas_blast",
                                "§5Crape Myrtle §0Eight Trigrams §6Immortal Forging Furnace", "§5紫薇§8八卦§6炼仙炉");

                provider.add("gtecore.xuanwu_module.enabled", "§8Black Tortoise Module§2 Enabled", "§8玄武阵法§2启动");
                provider.add("gtecore.xuanwu_module.disabled", "§8Black Tortoise Module§4 Disabled", "§8玄武阵法§4关闭");

                provider.add("gtecore.qinglong_module.enabled", "§3Azure Dragon Module§2 Enabled", "§3青龙阵法§2启动");
                provider.add("gtecore.qinglong_module.disabled", "§3Azure Dragon Module§4 Disabled", "§3青龙阵法§4关闭");

                provider.add("gtecore.zhuque_module.enabled", "§cVermilion Bird Module§2 Enabled", "§c朱雀阵法§2启动");
                provider.add("gtecore.zhuque_module.disabled", "§cVermilion Bird Module§4 Disabled", "§c朱雀阵法§4关闭");

                provider.add("gtecore.baihu_module.enabled", "§fWhite Tiger Module§2 Enabled", "§f白虎阵法§2启动");
                provider.add("gtecore.baihu_module.disabled", "§fWhite Tiger Module§4 Disabled", "§f白虎阵法§4关闭");

                provider.add("block.gtecore.big_bender", "Large Bender", "大型卷板机");
                provider.add("block.gtecore.big_wiremill", "Large WireMill", "大型线缆轧机");
                provider.add("block.gtecore.big_mixer", "Large Mixer", "大型搅拌机");
                provider.add("block.gtecore.big_gas_collector", "Large Gas Collector", "大型集气室");
                provider.add("block.gtecore.big_electrolyzer", "Large Electrolyzer", "大型电解机");
                provider.add("block.gtecore.big_wash", "Large Wash", "大型复合洗矿机");
                provider.add("block.gtecore.big_centrifuge", "Large Centrifuge", "大型离心机");
                provider.add("block.gtecore.big_brewery", "LargeBrewery", "大型酿造厂");
                provider.add("block.gtecore.big_extractor", "Large Fluid Extraction and Solidification Machine",
                                "大型流体提取固化一体机");
                provider.add("block.gtecore.big_extruder", "Large Extruder Array", "大型压模阵列");
                provider.add("block.gtecore.big_autoclave", "Large Autoclave", "大型高压釜");

                provider.add("block.gtecore.taichi_five_elements_separation_array",
                                "Tai Chi Five Elements Separation Array", "太极五行剥离阵列");
                provider.add("gtecore.taichi_five_elements_separating", "Tai Chi Five Elements Separating", "太极五行剥离");

                provider.add("block.gtecore.kun_gen_star_hub", "Kun Gen Star Hub", "坤艮星枢");
                provider.add("gtecore.kun_gen_star_hub", "Kun Gen Star Hub", "坤艮星枢");

                provider.add("block.gtecore.qian_qiong_engine", "Qian Qiong Engine", "谦穹引擎");
                provider.add("gtecore.qian_qiong_engine", "Qian Qiong Engine", "谦穹引擎");

                provider.add("block.gtecore.red_sun_tao_core", "§4Red Sun§rTao Core", "§4赤阳§r道核");
                provider.add("gtecore.red_sun_tao_core", "§4Red Sun§rTao Core", "§4赤阳§r道核");

                provider.add("block.gtecore.ashing_star_fusion_array", "Ashing Star Fusion Array", "烬星聚变阵");
                provider.add("gtecore.ashing_star_fusion_array", "Ashing Star Fusion Array", "烬星聚变阵");

                provider.add("item.gtecore.yin_yang_cpu_wafer", "§8Yin§rYang CPU Wafer", "§8阴§r阳CPU晶圆");
                provider.add("item.gtecore.yin_yang_circuit_board", "§8Yin§rYang Circuit Board", "§8阴§r阳电路板");
                provider.add("item.gtecore.yin_yang_boule", "§8Yin§rYang Boule", "§8阴§r阳单晶硅");
                provider.add("item.gtecore.yin_yang_circuit_chip", "§8Yin§rYang Circuit Chip", "§8阴§r阳电路芯片");

                provider.add("item.gtecore.imaginary_tree_boule", "§bImaginary Tree Boule", "§b虚数之树单晶硅");
                provider.add("item.gtecore.imaginary_tree_wafer", "§bImaginary Tree Wafer", "§b虚数之树晶圆");
                provider.add("item.gtecore.imaginary_tree_cpu_wafer", "§bImaginary Tree CPU Wafer", "§b虚数之树CPU晶圆");
                provider.add("item.gtecore.imaginary_tree_circuit_chip", "§bImaginary Tree Circuit Chip", "§b虚数之树电路芯片");
                provider.add("item.gtecore.imaginary_tree_circuit_board", "§bImaginary Tree Circuit Board",
                                "§b虚数之树电路基板");
                provider.add("item.gtecore.imaginary_tree_printed_circuit_board",
                                "§bImaginary Tree Printed Circuit Board", "§b虚数之树印刷电路基板");
                provider.add("item.gtecore.raw_imaginary_tree_chip", "§bRaw Imaginary Tree Chip", "§b粗制虚数晶片");
                provider.add("item.gtecore.engraved_imaginary_tree_chip", "§bEngraved Imaginary Tree Chip", "§b刻模虚数芯片");
                provider.add("item.gtecore.imaginary_tree_cpu_chip", "§bImaginary Tree CPU Chip", "§b虚数之树CPU芯片");
                provider.add("item.gtecore.imaginary_tree_soc", "§bImaginary Tree SoC", "§b虚数之树SoC");
                provider.add("item.gtecore.imaginary_tree_processor", "§bImaginary Tree Processor", "§b虚数之树处理器");
                provider.add("item.gtecore.imaginary_tree_processor.tooltip.0",
                                "§7Circuits grown upon the branches of the Imaginary Tree", "§7生长于虚数之树枝桠上的电路");
                provider.add("item.gtecore.imaginary_tree_processor.tooltip.1", "§bUHV-Level Circuits", "§bUHV级电路");
                provider.add("item.gtecore.imaginary_tree_processor_assembly", "§bImaginary Tree Processor Assembly",
                                "§b虚数之树处理器集群");
                provider.add("item.gtecore.imaginary_tree_processor_assembly.tooltip.0",
                                "§7Circuits grown upon the branches of the Imaginary Tree", "§7生长于虚数之树枝桠上的电路");
                provider.add("item.gtecore.imaginary_tree_processor_assembly.tooltip.1", "§bUEV-Level Circuits",
                                "§bUEV级电路");
                provider.add("item.gtecore.imaginary_tree_processor_computer", "§bImaginary Tree Processor Computer",
                                "§b虚数之树处理器超级计算机");
                provider.add("item.gtecore.imaginary_tree_processor_computer.tooltip.0",
                                "§7Circuits grown upon the branches of the Imaginary Tree", "§7生长于虚数之树枝桠上的电路");
                provider.add("item.gtecore.imaginary_tree_processor_computer.tooltip.1", "§bUIV-Level Circuits",
                                "§bUIV级电路");
                provider.add("item.gtecore.imaginary_tree_processor_mainframe", "§bImaginary Tree Processor Mainframe",
                                "§b虚数之树处理器主机");
                provider.add("item.gtecore.imaginary_tree_processor_mainframe.tooltip.0",
                                "§7Circuits grown upon the branches of the Imaginary Tree", "§7生长于虚数之树枝桠上的电路");
                provider.add("item.gtecore.imaginary_tree_processor_mainframe.tooltip.1", "§bUXV-Level Circuits",
                                "§bUXV级电路");

                provider.add("recipe.condition.bai_hu.tooltip", "Need §fWhite Tiger Module§2 Enabled", "需要§f白虎阵法§2启动");
                provider.add("recipe.condition.qing_long.tooltip", "Need §3Azure Dragon Module§2 Enabled",
                                "需要§3青龙阵法§2启动");
                provider.add("recipe.condition.xuan_wu.tooltip", "Need §8Black Tortoise Module§2 Enabled",
                                "需要§8玄武阵法§2启动");
                provider.add("recipe.condition.zhu_que.tooltip", "Need §cVermilion Bird Module§2 Enabled",
                                "需要§c朱雀阵法§2启动");

                provider.add("block.gtecore.big_alloy", "Large Alloy", "大型蒸汽合金炉");
                provider.add("block.gtecore.big_compressor", "Large Compressor", "大型蒸汽压缩机");
                provider.add("block.gtecore.component_factory", "Component Factory", "零件工厂");
                provider.add("gtecore.circuit_factory", "Circuit Factory", "电路工厂");
                provider.add("gtecore.component_factory", "Component Factory", "零件工厂");
                provider.add("block.gtecore.circuit_factory", "Circuit Factory", "电路工厂");
                provider.add("block.gtecore.big_forge_hammer", "Large Steam Forge Hammer", "大型蒸汽锻造锤");
                provider.add("block.gtecore.big_steam_extractor", "Large Steam Extractor", "大型蒸汽提取机");
                provider.add("block.gtecore.miracle_ring", "Miracle Ring", "奇迹之环");

                provider.add("block.gtecore.steam_oven_easy", "Steam Oven Easy Version", "蒸汽熔炼炉简单版");
                provider.add("block.gtecore.steam_grinder_easy", "Steam Grinder Easy Version", "蒸汽碾磨机简单版");
                provider.add("block.gtecore.desulfurization", "Desulfurizating Machine", "脱硫机");
                provider.add("gtecore.desulfurization_recipe", "Desulfurizing", "脱硫");

                provider.add("block.gtecore.me_pattern_buffer_plus", "ME Pattern Buffer Plus", "ME样板总成Plus版");
                provider.add("block.gtecore.me_pattern_buffer_proxy_plus", "ME Pattern Buffer Proxy Plus",
                                "ME样板总成镜像Plus版");

                provider.add("block.gtecore.pattern_buffer_proxy_plus.desc.0",
                                "§fAllows linking many machines to a singular §6ME Pattern Buffer Plus§f.",
                                "§f可以将单单一个§6ME样板总成Plus§f连接到众多机器。");
                provider.add("block.gtecore.pattern_buffer_proxy_plus.desc.1",
                                "§fAll connected proxies will share the patterns held within the §6original buffer§f.",
                                "§f所有连接的总成镜像将共享§6原始总成§f中的样板。");
                provider.add("block.gtecore.pattern_buffer_proxy_plus.desc.2",
                                "§fLet the factory grow!", "让工厂蓬勃发展!");
                provider.add("block.gtecore.pattern_buffer_plus.desc.0",
                                "§fAllows direct §6AE2 pattern storage §ffor GregTech Multiblocks.",
                                "§f对于GT多方块结构的集成式§6AE2样板供应器§f。");
                provider.add("block.gtecore.pattern_buffer_plus.desc.1",
                                "§fAE2 Patterns can utilize anything stored in the §6shared inventory §fwidget.",
                                "§fAE2样板可以利用§6共享库存§f中的一切。");
                provider.add("block.gtecore.pattern_buffer_plus.desc.2",
                                "§fLink §6Pattern Buffer Proxies §fwith a §bdatastick §fto link machines together!",
                                "§f使用§b闪存§f绑定§6ME样板总成镜像§f，以使机器相互连接！");

                provider.add("block.gtecore.pattern_buffer_plus.desc.3",
                                "With 81 sample slots, it supports the functionality of programmable storage, enabling the output of items and fluids",
                                "拥有81个样板槽位，支持可编程仓的功能,支持输出物品和流体");

                provider.add("config.jade.plugin_gtecore.me_pattern_buffer_plus", "Pattern Buffer Plus Info",
                                "样板总成Plus版信息");
                provider.add("config.jade.plugin_gtecore.me_pattern_buffer_proxy_plus", "Pattern Buffer Proxy PlusInfo",
                                "样板总成镜像Plus版信息");
                provider.add("gtecore.top.buffer_not_bound", "Buffer Plus Not Currently Bound", "尚未绑定样板总成Plus版");
                provider.add("gtecore.top.proxies_bound", "Buffer Proxies Plus Bound: %s", "样板总成镜像Plus版绑定数量：%s");
                provider.add("gtecore.top.buffer_bound_pos", "Bound To - X: %s, Y: %s, Z: %s", "已绑定至 - X：%s；Y：%s；Z：%s");
                provider.add("com.gtecore.tooltips.yin_yang_eight_trigmas_blast_furnace.0",
                                "Due to feng shui reasons, the machine apparently needs to face south in order to function properly.",
                                "由于风水原因，机器似乎必须正面朝南才能正常的工作");

                provider.add("com.gtecore.structure_tesing.tooltips.failure", "§cStructure Testing Failure", "§c结构未成型");
                provider.add("com.gtecore.structure_tesing.tooltips.success", "§2Structure Testing Success", "§2结构已成型");
                provider.add("item.gtecore.check_structure_terminal", "Structure Testing Terminal", "结构检测终端");
                provider.add("gtecore.structure_terminal.tooltip.check", "Sneak-right-click a controller to diagnose its structure", "潜行右键控制器，检测当前结构");
                provider.add("gtecore.structure_terminal.tooltip.preview", "Right-click for an example preview; repeat to cycle layers", "右键显示示例结构预览，再次右键逐层查看");
                provider.add("gtecore.structure_terminal.success", "Structure matches (this does not check operating requirements)", "结构检测通过（不代表已满足运行条件）");
                provider.add("gtecore.structure_terminal.failure", "Structure does not match; fix the reported issue and check again", "结构检测未通过；修复提示的问题后再次检测");
                provider.add("gtecore.structure_terminal.position", "Check X: %s, Y: %s, Z: %s", "检查位置 X：%s，Y：%s，Z：%s");
                provider.add("gtecore.structure_terminal.candidates", "Candidate blocks (up to 8; count and tier constraints still apply): %s", "候选方块（最多8项，仍须满足数量与等级限制）：%s");
                provider.add("gtecore.structure_terminal.wrong_block", "The block here does not satisfy the structure rule", "此处方块不满足结构要求");
                provider.add("gtecore.structure_terminal.no_pattern", "This controller has no structure pattern to inspect", "此控制器没有可检测的结构图案");
                provider.add("gtecore.structure_terminal.unloaded", "Part of the structure is in an unloaded chunk; load it and check again", "部分结构所在区块未加载，请加载后再次检测");
                provider.add("gtecore.structure_terminal.error", "Could not inspect this structure; see the game log for details", "无法检测此结构，详细原因见游戏日志");
                provider.add("gtecore.structure_terminal.no_preview", "No example preview is available for this controller", "此控制器没有可用的示例结构预览");
                provider.add("gtecore.structure_terminal.preview_orientation", "Example preview is unavailable for mirrored or vertically facing controllers; structure detection still works", "镜像或垂直朝向控制器暂不支持示例预览，结构检测仍可使用");
                provider.add("gtecore.structure_terminal.preview", "Showing the first example design; right-click again to cycle layers", "正在显示第一种示例结构；再次右键可逐层查看");

                provider.add("com.gtecore.structure_tesing.tooltips.at", "At", "位于");
                provider.add("com.gtecore.structure_tesing.tooltips.place_error", "founded placement error", "不应该放置在这");

                provider.add("block.gtecore.general_fuel_engine", "General Fuel Engine", "通用燃料引擎");
                provider.add("block.gtecore.ecological_simulator", "Ecological Simulator", "生态圈模拟器");

                provider.add("block.gtecore.mega_alloy_smelter_blast", "MEGA Alloy Smelter Blast Furnace", "巨型合金冶炼炉");
                provider.add("block.gtecore.mega_dehydrator", "MEGA Dehydrator", "巨型脱水机");

                provider.add("block.gtecore.rare_earth_processing_plant", "Rare Earth Processing Plant", "稀土处理工厂");
                provider.add("gtecore.rare_earth_processing", "Rare Earth Processing", "稀土处理");

                provider.add("block.gtecore.tree_of_imaginary", "§bTree of Imaginary", "§b虚数之树");
                provider.add("gtecore.tree_of_imaginary", "§bTree of Imaginary", "§b虚数之树");
                provider.add("com.gtecore.tooltips.tree_of_imaginary.0", "§7Infinite branches woven from the fabric of dimensions", "§7交织于维度织理中的无尽枝桠");
                provider.add("com.gtecore.tooltips.tree_of_imaginary.1", "§bOctree 3D Fractal Dimensional Engine", "§b八叉树立体分形维度引擎");

                // Casings and Modules
                provider.add("block.gtecore.imaginary_casing", "§bImaginary Casing", "§b虚数外壳");
                provider.add("block.gtecore.imaginary_core_casing", "§bImaginary Core Casing", "§b虚数核心外壳");
                provider.add("block.gtecore.imaginary_branch_casing", "§bImaginary Branch Casing", "§b虚数枝桠外壳");
                provider.add("block.gtecore.imaginary_containment_casing", "§bImaginary Containment Casing",
                                "§b虚数约束外壳");
                provider.add("block.gtecore.imaginary_coil_block", "§bImaginary Coil Block", "§b虚数线圈方块");
                provider.add("block.gtecore.imaginary_energy_conduit", "§bImaginary Energy Conduit", "§b虚数能量导管");
                provider.add("block.gtecore.imaginary_glass", "§bImaginary Glass", "§b虚数玻璃");
                provider.add("block.gtecore.imaginary_leaf_matrix", "§bImaginary Leaf Matrix", "§b虚数叶矩阵");
                provider.add("block.gtecore.yin_yang_coil_block", "§f§0Yin Yang Coil Block", "§f§0阴阳线圈方块");
                provider.add("block.gtecore.base_dark_concrete", "Base Dark Concrete", "深色基础混凝土");
                provider.add("block.gtecore.base_light_concrete", "Base Light Concrete", "浅色基础混凝土");
                provider.add("block.gtecore.base_mid_concrete", "Base Mid Concrete", "中色基础混凝土");
                provider.add("block.gtecore.yin_yang_field_restriction", "§f§0Yin Yang Field Restriction Casing",
                                "§f§0阴阳场约束机械外壳");
                provider.add("block.gtecore.baihu_module", "§fBaihu Module", "§f白虎模组");
                provider.add("block.gtecore.qinglong_module", "§aQinglong Module", "§a青龙模组");
                provider.add("block.gtecore.xuanwu_module", "§0Xuanwu Module", "§0玄武模组");
                provider.add("block.gtecore.zhuque_module", "§cZhuque Module", "§c朱雀模组");

                // Purified Water Fluids
                provider.add("material.gtecore.distilled_purified_water", "§3Distilled Purified Water", "§3蒸馏净化水");
                provider.add("material.gtecore.uv_purified_water", "§9Ultraviolet Purified Water", "§9紫外净化水");
                provider.add("material.gtecore.ultrapure_water", "§bUltrapure Purified Water", "§b电子级净化水");
                provider.add("material.gtecore.composite_flocculant", "Composite Flocculant Reagent", "高纯复合絮凝液");
                provider.add("material.gtecore.ozone", "High Purity Ozone", "高纯臭氧");
                provider.add("material.gtecore.electronic_acid_base_reagent", "Electronic Acid-Base Reagent", "电子级酸碱脱附液");

                // Purified Water Precursor Items
                provider.add("item.gtecore.modified_carbon_microspheres", "Modified Carbon Microspheres", "改性纳米活性炭微球");
                provider.add("item.gtecore.mixed_bed_resin_beads", "Mixed Bed Resin Beads", "电子级混床离子交换树脂微球");

                // Ultrapure Water Refinery
                provider.add("block.gtecore.ultrapure_water_refinery", "§bUltrapure Water Refinery", "§b超纯水综合精炼中心");
                provider.add("gtecore.ultrapure_water_refinery", "§bUltrapure Water Refinery", "§b超纯水综合精炼中心");
                // Water Purification Recipe Types & Categories
                provider.add("gtecore.water_purification", "Water Purification", "水质净化精炼");
                provider.add("gtceu.water_purification", "Water Purification", "水质净化精炼");
                provider.add("recipe.gtecore.water_purification", "Water Purification", "水质净化精炼");
                provider.add("recipe.gtceu.water_purification", "Water Purification", "水质净化精炼");
                provider.add("recipe_type.gtecore.water_purification", "Water Purification", "水质净化精炼");
                provider.add("recipetype.gtecore.water_purification", "Water Purification", "水质净化精炼");
                provider.add("gtecore.recipe.category.water_purification", "Water Purification", "水质净化精炼");
                provider.add("gtceu.recipe.category.water_purification", "Water Purification", "水质净化精炼");

                // Individual Water Purification Recipes
                provider.add("recipe.gtecore.distilled_purified_water_from_water", "Distilled Purified Water (Water)", "蒸馏净化水（生水澄清）");
                provider.add("recipe.gtceu.distilled_purified_water_from_water", "Distilled Purified Water (Water)", "蒸馏净化水（生水澄清）");
                provider.add("recipe.gtecore.distilled_purified_water_from_distilled", "Distilled Purified Water (Distilled Water)", "蒸馏净化水（蒸馏水澄清）");
                provider.add("recipe.gtceu.distilled_purified_water_from_distilled", "Distilled Purified Water (Distilled Water)", "蒸馏净化水（蒸馏水澄清）");
                provider.add("recipe.gtecore.uv_purified_water_from_ozone", "UV Purified Water (Ozone)", "紫外净化水（臭氧氧化）");
                provider.add("recipe.gtceu.uv_purified_water_from_ozone", "UV Purified Water (Ozone)", "紫外净化水（臭氧氧化）");
                provider.add("recipe.gtecore.uv_purified_water_from_peroxide", "UV Purified Water (Hydrogen Peroxide)", "紫外净化水（双氧水高级氧化）");
                provider.add("gtceu.recipe.uv_purified_water_from_peroxide", "UV Purified Water (Hydrogen Peroxide)", "紫外净化水（双氧水高级氧化）");
                provider.add("recipe.gtecore.ultrapure_water", "Ultrapure Water (EDI)", "电子级超纯水（电去离子）");
                provider.add("gtceu.recipe.ultrapure_water", "Ultrapure Water (EDI)", "电子级超纯水（电去离子）");
                provider.add("recipe.gtecore.ultrapure_water_regeneration", "EDI Resin Regeneration (Cleaning)", "EDI 树脂再生（清洗）");
                provider.add("gtceu.recipe.ultrapure_water_regeneration", "EDI Resin Regeneration (Cleaning)", "EDI 树脂再生（清洗）");
                provider.add("com.gtecore.tooltips.ultrapure_water_refinery.0", "§cRetired machine: retained for existing worlds; no processing recipes", "§c已停用：仅为兼容旧存档保留，不再执行配方");
                provider.add("com.gtecore.tooltips.ultrapure_water_refinery.1", "§bMigrate to the central plant and T1 / T2 / T3 purification units", "§b请迁移至中枢净化水厂与一、二、三级净化单元");

                // Central Water Purification Plant & Tiered Purification Units
                provider.add("block.gtecore.central_water_purification_plant", "§bCentral Water Purification Plant", "§b中枢净化水厂");
                provider.add("gtecore.central_water_purification_plant", "§bCentral Water Purification Plant", "§b中枢净化水厂");
                provider.add("block.gtecore.t1_clarifier_purification_unit", "§3T1 Clarifier Purification Unit", "§3一级澄清净化装置");
                provider.add("gtecore.t1_clarifier_purification_unit", "§3T1 Clarifier Purification Unit", "§3一级澄清净化装置");
                provider.add("block.gtecore.t2_uv_oxidation_purification_unit", "§9T2 UV-Oxidation Purification Unit", "§9二级紫外氧化净化装置");
                provider.add("gtecore.t2_uv_oxidation_purification_unit", "§9T2 UV-Oxidation Purification Unit", "§9二级紫外氧化净化装置");
                provider.add("block.gtecore.t3_edi_ultrapure_purification_unit", "§dT3 EDI Ultrapure Purification Unit", "§d三级 EDI 超纯净化装置");
                provider.add("gtecore.t3_edi_ultrapure_purification_unit", "§dT3 EDI Ultrapure Purification Unit", "§d三级 EDI 超纯净化装置");

                provider.add("com.gtecore.tooltips.central_water_purification_plant.0", "§7Control hub of the purified water line: binds every tier of purification unit with a data stick", "§7整条净水产线的控制核心：用数据棒连接各级净化单元");
                provider.add("com.gtecore.tooltips.central_water_purification_plant.1", "§bSupplies EU to every bound unit and broadcasts the parallel setting configured in its GUI", "§b为全部已连接单元供电，并下发 GUI 中设定的并行度");
                provider.add("com.gtecore.tooltips.central_water_purification_plant.2", "§cPurification units cannot start until bound to a formed plant", "§c未连接到已成型中枢的净化单元无法开机");

                provider.add("com.gtecore.tooltips.t1_clarifier_purification_unit.0", "§7Multi-effect flash distillation for the UEV Imaginary-series water supply", "§7服务于 UEV 虚数系列供水的多效闪蒸精馏澄清装置");
                provider.add("com.gtecore.tooltips.t1_clarifier_purification_unit.1", "§3Water / Distilled Water -> Distilled Purified Water; requires a bound central plant", "§3普通水/蒸馏水 → 蒸馏净化水；需连接中枢净化水厂");
                provider.add("com.gtecore.tooltips.t2_uv_oxidation_purification_unit.0", "§7DUV photolysis and advanced oxidation for the UEV Imaginary-series water supply", "§7服务于 UEV 虚数系列供水的深紫外光解高级氧化装置");
                provider.add("com.gtecore.tooltips.t2_uv_oxidation_purification_unit.1", "§9Distilled Purified Water -> UV Purified Water; requires a bound central plant", "§9蒸馏净化水 → 紫外净化水；需连接中枢净化水厂");
                provider.add("com.gtecore.tooltips.t3_edi_ultrapure_purification_unit.0", "§7Electrodeionization and sub-nanometer polishing for the UEV Imaginary-series water supply", "§7服务于 UEV 虚数系列供水的连续电去离子与亚纳米精抛装置");
                provider.add("com.gtecore.tooltips.t3_edi_ultrapure_purification_unit.1", "§dUV Purified Water -> Ultrapure Water; requires a bound central plant", "§d紫外净化水 → 电子级净化水；需连接中枢净化水厂");

                provider.add("com.gtecore.gui.water_plant.parallel", "Parallel", "并行度");
                provider.add("com.gtecore.tooltips.water_plant.parallel", "§6Parallel setting: %s", "§6并行度设定：%s");
                provider.add("com.gtecore.tooltips.water_plant.units", "§bLinked purification units: %s", "§b已连接净化单元：%s");
                provider.add("com.gtecore.tooltips.water_plant.throughput", "§ePower transferred: %s EU/s", "§e实际输出功率：%s EU/s");
                provider.add("com.gtecore.tooltips.water_plant.link_hint", "§7Right-click a purification unit with a data stick holding this plant's position", "§7手持存有本机坐标的数据棒右键净化单元即可连接");

                provider.add("com.gtecore.tooltips.water_unit.unlinked", "§cNot linked to a central plant - cannot operate", "§c未连接中枢净化水厂，无法开机");
                provider.add("com.gtecore.tooltips.water_unit.link_hint", "§7Right-click this unit with a data stick holding the plant's position", "§7请手持存有中枢坐标的数据棒右键本机");
                provider.add("com.gtecore.tooltips.water_unit.linked", "§bCentral plant at %s, %s, %s", "§b中枢净化水厂坐标：%s, %s, %s");
                provider.add("com.gtecore.tooltips.water_unit.parallel", "§6Parallel received from plant: %s", "§6中枢下发的并行度：%s");
                provider.add("com.gtecore.tooltips.water_unit.energy", "§eInternal EU buffer: %s / %s", "§e内部电力缓冲：%s / %s");

                provider.add("com.gtecore.chat.water_plant.bound", "Purification unit bound to this plant", "已连接该净化单元");
                provider.add("com.gtecore.chat.water_plant.bind_failed", "The data stick does not hold a purification unit position", "数据棒中没有净化单元坐标");
                provider.add("com.gtecore.chat.water_plant.copied", "Central plant position copied to the data stick", "已复制中枢净化水厂坐标");
                provider.add("com.gtecore.chat.water_unit.linked", "Linked to the central water purification plant", "已连接中枢净化水厂");
                provider.add("com.gtecore.chat.water_unit.link_failed", "The data stick does not hold a central plant position", "数据棒中没有中枢净化水厂坐标");
                provider.add("com.gtecore.chat.water_unit.copied", "Purification unit position copied to the data stick", "已复制净化单元坐标");
                provider.add("block.gtecore.thermal_control_hatch", "Thermal Control Hatch", "温控仓");
                provider.add("block.gtecore.uv_lamp_hatch", "UV Lamp Hatch", "紫外灯组仓");
                provider.add("block.gtecore.edi_load_signal_hatch", "EDI Load Signal Hatch", "EDI 负载信号输出仓");
                provider.add("block.gtecore.edi_regeneration_control_hatch", "EDI Regeneration Control Hatch", "EDI 再生控制仓");
                provider.add("gtecore.water.edi.title", "T3 / EDI ULTRAPURE WATER", "三级净化 · EDI 超纯水");
                provider.add("gtecore.water.edi.load", "Ion load: %s / %s mB-equivalent", "离子负载：%s / %s mB 当量");
                provider.add("gtecore.water.edi.signal", "Load signal: %s / 15", "负载信号：%s / 15");
                provider.add("gtecore.water.edi.requested", "Requested mode: %s", "请求模式：%s");
                provider.add("gtecore.water.edi.active", "Active batch: %s, %s parallel", "当前批次：%s，%s 并行");
                provider.add("gtecore.water.edi.production", "Production", "制水");
                provider.add("gtecore.water.edi.regeneration", "Regeneration", "再生清洗");
                provider.add("gtecore.water.edi.full", "Ion load full; regeneration required", "离子负载已满，需要再生清洗");
                provider.add("gtecore.water.edi.clean", "Resin clean; waiting without consuming resources", "树脂已清洁，待机不消耗资源");
                provider.add("gtecore.water.edi.unlinked", "Waiting for the central plant", "等待中枢连接及供电");
                provider.add("gtecore.water.edi.unformed", "Structure incomplete", "结构未成型");
                provider.add("gtecore.water.edi.waiting", "Ready; waiting for a recipe", "就绪，等待配方");
                provider.add("gtecore.water.edi.processing", "EDI processing in progress", "正在进行 EDI 处理");
                provider.add("gtecore.water.edi.time", "Processing: %s / %s ticks", "加工进度：%s / %s tick");
                provider.add("gtecore.water.edi.output_blocked", "Processing complete; waiting for output space", "加工完成，等待输出空间");
                provider.add("gtecore.water.edi.rule", "External redstone control: signal >= 12 sets regeneration; <= 3 resets; 4-11 holds the RS latch.", "外部红石控制：信号 ≥12 置位再生，≤3 复位；4～11 由 RS 锁存器保持。");
                provider.add("gtecore.water.edi.signal_hatch.help", "Front outputs raw load signal 0-15. Use comparison-mode comparators: reference 12 to set; invert reference 4 to reset.", "正面输出原始负载信号 0～15。比较器使用比较模式：侧输入 12 置位；侧输入 4 后反相复位。");
                provider.add("gtecore.water.edi.control_hatch.help", "Any redstone signal requests regeneration; no signal requests production. Changes apply to the next batch.", "收到任意强度红石信号请求再生，无信号请求制水；切换在下一批次生效。");
                provider.add("gtecore.water.edi.control_hatch.signal", "Control signal: %s", "控制信号：%s");
                provider.add("gtecore.water.edi.mode_next_batch", "Mode is locked per batch; external redstone controls the next batch.", "每批锁定运行模式，外部红石控制下一批次。");
                provider.add("gtecore.water.uv.title", "T2 / UV OXIDATION", "二级净化 · 紫外氧化");
                provider.add("gtecore.water.uv.lamps", "Installed lamps: %s / 4", "已安装灯组：%s / 4");
                provider.add("gtecore.water.uv.power", "Next batch power: %s%%", "下批功率：%s%%");
                provider.add("gtecore.water.uv.batch", "Active batch: %s parallel at %s%% power", "当前批次：%s 并行，%s%% 功率");
                provider.add("gtecore.water.uv.dose", "UV dose: %s / %s", "紫外剂量：%s / %s");
                provider.add("gtecore.water.uv.time", "Processing: %s / %s ticks", "加工进度：%s / %s tick");
                provider.add("gtecore.water.uv.idle", "Ready; waiting for a recipe", "就绪，等待配方");
                provider.add("gtecore.water.uv.unformed", "Structure incomplete", "结构未成型");
                provider.add("gtecore.water.uv.unlinked", "Waiting for the central plant", "等待中枢连接及供电");
                provider.add("gtecore.water.uv.processing", "UV exposure in progress", "正在紫外照射");
                provider.add("gtecore.water.uv.output_blocked", "Dose complete; waiting for output space", "剂量达标，等待输出空间");
                provider.add("gtecore.water.uv.no_lamps", "Install at least one UV lamp hatch", "请安装至少一个紫外灯组仓");
                provider.add("gtecore.water.uv.invalid_batch", "Saved batch has no valid UV dose data; restart the batch", "存档批次缺少有效紫外剂量数据，请重新开始批次");
                provider.add("gtecore.water.uv.next_batch", "Power changes apply to the next batch", "功率调整在下一批次生效");
                provider.add("gtecore.water.uv.lamp.title", "UV LAMP HATCH", "紫外灯组仓");
                provider.add("gtecore.water.uv.lamp.help", "Each lamp supports 64 parallel at full power and uses the central plant's shared energy; no separate energy hatch required.", "每组灯在满功率下提供 64 并行照射能力，共用中枢供电，无需独立能源仓。");
                provider.add("gtecore.water.uv.help", "Install 1-4 lamps; select 25/50/75/100% power. Lower power or greater parallel extends exposure. Water is released only at full dose.", "安装 1～4 组灯，选择 25/50/75/100% 功率；降低功率或提高并行会延长照射，剂量达标后才产水。");
                provider.add("block.gtecore.thermal_signal_hatch", "Thermal Signal Hatch", "温控信号输出仓");
                provider.add("gtecore.water.thermal_signal.help", "Wire the front output to the thermal control hatch: 15 requests heating, 0 requests cooling; target center +/- 1 C hysteresis.", "将正面输出接到温控仓：15 请求升温，0 请求降温；围绕目标中心保留 ±1 ℃ 缓冲区。");
                provider.add("gtecore.water.thermal_signal.signal", "Redstone output: %s", "红石输出：%s");
                provider.add("gtecore.water.thermal_signal.heating", "Requesting heat", "请求升温");
                provider.add("gtecore.water.thermal_signal.cooling", "Requesting cooling", "请求降温");
                provider.add("gtecore.water.thermal_signal.disconnected", "No formed thermal controller connected", "未关联已成型的控温主机");
                provider.add("gtecore.water.thermal_hatch.signal", "Redstone strength: %s", "红石强度：%s");
                provider.add("gtecore.water.thermal_hatch.heating", "Heating (+2 C/s)", "正在升温（+2 ℃/秒）");
                provider.add("gtecore.water.thermal_hatch.cooling", "Cooling (-2 C/s)", "正在降温（-2 ℃/秒）");
                provider.add("gtecore.water.thermal_hatch.help", "Apply redstone to any side to heat; remove the signal to cool.", "任意一面输入红石信号即可升温；无信号时降温。");
                provider.add("gtecore.water.thermal.manual_maintenance", "Requires an ordinary maintenance hatch; thermal faults require repairs.", "必须使用普通维护仓；温控故障需要维修。");
                provider.add("gtecore.water.thermal.title", "T1 / THERMAL PURIFICATION", "一级净化 · 温度监控");
                provider.add("gtecore.water.thermal.temperature", "Temperature: %s C", "当前温度：%s ℃");
                provider.add("gtecore.water.thermal.range", "Target: %s - %s C", "目标温区：%s～%s ℃");
                provider.add("gtecore.water.thermal.yield", "Water yield: %s%%", "净化水产出率：%s%%");
                provider.add("gtecore.water.thermal.stable", "Stable: %s / 600 s", "稳定运行：%s / 600 秒");
                provider.add("gtecore.water.thermal.next_target", "Next target in %s s", "下次变温：%s 秒");
                provider.add("gtecore.water.thermal.grace", "Out of range: %s s of operating grace left", "温度越界：剩余运行缓冲 %s 秒");
                provider.add("gtecore.water.thermal.in_range", "Temperature is within the safe band", "温度处于安全区间");
                provider.add("gtecore.water.thermal.fault_hint", "Thermal trip: repair the maintenance hatch and return to the safe band.", "温控故障：修复维护仓并将温度调回安全区间。");
                provider.add("gtecore.water.thermal.maintenance_disabled", "Enable GTM maintenance to operate this unit.", "需要启用 GTM 维修机制才能运行本机。");
                provider.add("gtecore.water.thermal.maintenance_required", "Repair the maintenance hatch before starting.", "请先修好维护仓再开始运行。");
                provider.add("gtecore.water.thermal.rule", "Target changes every 60 operating seconds; 15 seconds to recover.", "每运行 60 秒改变温区；连续越界缓冲为 15 秒。");
                provider.add("gtecore.water.thermal.efficiency_hint", "600 stable operating seconds reach 100% water yield; thermal trips reset yield and require maintenance.", "稳定运行 600 秒达到 100% 净化水产出；温控超时将清零产出率并触发维修。");
                provider.add("gtecore.water.thermal.idle_rule", "Idle resets yield; out-of-range grace pauses yield growth.", "停机会重置产出率；越界缓冲期间不积累稳定时间。");
                provider.add("gtecore.water.thermal.link_status", "Plant parallel limit: %s", "中枢并行上限：%s");
                provider.add("com.gtecore.gui.water_plant.dashboard", "WATER PURIFICATION / CONTROL", "水处理 · 中央控制");
                provider.add("com.gtecore.gui.water_plant.incomplete", "STRUCTURE OFFLINE", "结构未成型");
                provider.add("com.gtecore.gui.water_plant.disabled", "TRANSFER PAUSED", "供电已暂停");
                provider.add("com.gtecore.gui.water_plant.online", "NETWORK ONLINE", "供电网络在线");
                provider.add("com.gtecore.gui.water_plant.network", "Ready / registered units: %s / %s", "已就绪 / 已登记单元：%s / %s");
                provider.add("com.gtecore.gui.water_plant.tiers", "T1 %s / T2 %s / T3 %s", "一级 %s / 二级 %s / 三级 %s");
                provider.add("com.gtecore.gui.water_plant.storage", "Stored: %s / %s EU", "储能：%s / %s EU");
                provider.add("com.gtecore.gui.water_plant.parallel_scope", "Per-unit limit: %s (next cycle)", "单元并行上限：%s（下一周期生效）");
                provider.add("com.gtecore.gui.water_plant.link_instruction", "Data stick: sneak-use to copy; use on the other controller to link.", "数据棒：潜行右键复制地址，右键另一端控制器绑定。");
                provider.add("com.gtecore.gui.water_plant.disconnect_all", "Disconnect all", "断开全部");
                provider.add("com.gtecore.gui.water_unit.disconnect", "Disconnect plant", "断开中枢");
        }
}
